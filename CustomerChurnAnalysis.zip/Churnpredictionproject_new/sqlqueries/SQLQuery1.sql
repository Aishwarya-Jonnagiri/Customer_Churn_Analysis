Use db_Churn;
select * from stg_Churn;
