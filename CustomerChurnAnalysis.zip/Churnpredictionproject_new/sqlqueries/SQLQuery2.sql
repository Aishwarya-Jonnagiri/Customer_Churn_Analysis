Use db_Churn;
--data exploration---
---to understand more about data we have done the following----

Select Gender, COUNT(Gender) as TotalCount,
COUNT(Gender) * 100.0 / (Select COUNT(*) from stg_Churn) as Percentage
From stg_Churn
Group By Gender;

Select Contract, COUNT(Contract) as TotalCount,
COUNT(Contract) * 100.0 / (Select COUNT(*) from stg_Churn) as Percentage
From stg_Churn
Group By Contract;

---the below query tells us whether churn stayed or churned or any new customer has added that is based on Customer_Status column---
Select Customer_Status, Count(Customer_Status) as TotalCount, SUM(Total_Revenue) as TotalRev,
sum(Total_Revenue)/ (Select sum(Total_Revenue) from stg_Churn) * 100 as RevPercentage
from stg_Churn
Group by Customer_Status;

---lets see how many states represent what percentage of values and this query says which state has highest percentage of contribution in our data--- 

Select State, COUNT(State) as TotalCount,
COUNT(State) * 100.0 / (Select COUNT(*) from stg_Churn) as Percentage
From stg_Churn
Group By State
Order by percentage desc;

---to identify how many distinct items we have in a particular column---
Select Distinct Internet_Type
from stg_Churn;