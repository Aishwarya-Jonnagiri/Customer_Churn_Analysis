# Customer Churn Analysis  

## Project Overview  
Customer churn is a critical challenge for businesses relying on long-term subscriptions and services.  
This project focuses on predicting **customer churn using Random Forest** and generating actionable insights with **SQL, Power BI, and Python (Jupyter)**.  

The project combines **data analysis, visualization, and machine learning** to help businesses identify at-risk customers and design strategies to improve retention.  

---

## Objectives  
- Analyze churn patterns using **SQL queries** and data exploration.  
- Build **interactive dashboards in Power BI** for business insights.  
- Develop a **Random Forest model in Python** to predict churn.  
- Present actionable recommendations for customer retention.  

---

## Dataset  
The dataset includes:  
- **Demographics** – Gender, senior citizen status, dependents.  
- **Services** – Phone, internet, streaming, tech support.  
- **Accounts** – Tenure, contract type, billing method, charges.  
- **Target variable** – `Churn` (Yes/No).  

*(Dataset sourced from open churn datasets  Kaggle )*  

---

##  Tools & Technologies  
- **SQL Server Management Studio (SSMS)** → For data cleaning, preprocessing, and querying.  
- **Power BI Desktop** → For creating dashboards and visual reports.  
- **Jupyter Notebook** → For machine learning workflows and EDA.  
- **Python Libraries** → pandas, numpy, matplotlib, seaborn, scikit-learn, joblib.  
- **Algorithm** → Random Forest Classifier.  

---

##  Workflow  

1. **Data Preparation (SQL)**  
   - Imported raw dataset into SQL Server.  
   - Cleaned missing values and handled inconsistent records.  
   - Wrote queries to extract churn-related insights.  

2. **Exploratory Data Analysis (Power BI & Python)**  
   - Created interactive dashboards in **Power BI Desktop** to visualize churn distribution, service usage, and revenue impact.  
   - Used **Python (Jupyter)** for deeper statistical analysis and feature correlations.  

3. **Model Development (Python)**  
   - Implemented a **Random Forest Classifier**.  
   - Feature encoding and scaling.  
   - Hyperparameter tuning for optimized accuracy.  
   - Saved trained model.

4. **Evaluation Metrics**  
   - Accuracy  
   - Precision, Recall, F1-Score  
   - Confusion Matrix  
   

---

##  Model Results  

### Confusion Matrix  
```
[[783  64]
 [126 229]]
```  

- **True Negatives (Stayed correctly predicted):** 783  
- **False Positives (Stayed predicted as Churn):** 64  
- **False Negatives (Churn predicted as Stayed):** 126  
- **True Positives (Churn correctly predicted):** 229  

### Classification Report  
| Metric      | Class 0 (Stayed) | Class 1 (Churn) | Macro Avg | Weighted Avg |
|-------------|-----------------|-----------------|-----------|--------------|
| Precision   | 0.86            | 0.78            | 0.82      | 0.84         |
| Recall      | 0.92            | 0.65            | 0.78      | 0.84         |
| F1-score    | 0.89            | 0.71            | 0.80      | 0.84         |
| Support     | 847             | 355             | 1202      | 1202         |

###  Accuracy  
- **Overall Accuracy:** **84%**  

---

##  Key Insights  
- Customers on **month-to-month contracts** are at the highest risk of churn.  
- **Electronic check payments** show strong association with churn.  
- Customers with **long tenure** are less likely to leave.  
- Additional services (e.g., streaming TV/Internet) help retain customers.  

---

## Business Impact  
- The model identifies churn-prone customers with **84% accuracy**.  
- Businesses can now **prioritize at-risk customers** for retention campaigns.  
- Insights can inform targeted offers, discounts, or bundled services.  

---


##  Acknowledgments  
This project was developed as a portfolio project to demonstrate **SQL, Power BI, and Machine Learning skills** in solving a real-world business challenge.  

---

 *A complete end-to-end workflow combining data engineering, business intelligence, and predictive modeling for customer churn analysis.*  
